/*
	Sound Board
	by Maverick Loneshark
	5/22/2012
*/

using UnityEngine;
using System.Collections;

public class Button : MonoBehaviour
{
	Texture2D image; //reference to the original image
	Texture2D inverse; //inverse copy of the original image
	bool inverted; //flag that indicates when image colors are inverted
	
	// Use this for initialization
	void Start()
	{
		audio.loop = false;
		inverted = false;
		
		//store reference to original texture
		image = (Texture2D)guiTexture.texture;
		
		//create and store the inverse texture, instead of risking an overwrite of the original pixels
		initializeInverse();
		
		return;
	}
	
	//helper function: creates the inverse texture
	void initializeInverse()
	{
		//initialize inverse image
		inverse = new Texture2D(guiTexture.texture.width, guiTexture.texture.height);
		
		//copy the original pixels
		Color [] pixels = ((Texture2D)guiTexture.texture).GetPixels();
		
		//invert every pixel's colors
		for(int i = 0; i < pixels.Length; i++)
		{
			pixels[i].r = (1 - pixels[i].r);
			pixels[i].g = (1 - pixels[i].g);
			pixels[i].b = (1 - pixels[i].b);
		}
		
		//paint the changes to the 'canvas' image
		inverse.SetPixels(pixels);
		inverse.Apply();
		
		return;
	}
	
	// Update is called once per frame
	void Update()
	{
#if UNITY_ANDROID
		//get input for Android devices
		foreach(Touch touch in Input.touches)
		{
			if(touch.phase == TouchPhase.Began)
			{
				if(guiTexture.HitTest(touch.position)) //button is pressed
				{
					if(!audio.isPlaying) //prevent reactivation when already active
					{
						//invert image and play sound
						inverted = true;
						invert();
						audio.Play();
					}
				}
			}
		}
#else
		//get input for dev environment (Windows)
		if(Input.GetMouseButtonUp(0))
		{
			if(guiTexture.HitTest(Input.mousePosition)) //button is pressed
			{
				if(!audio.isPlaying) //prevent reactivation when already active
				{
					//invert image and play sound
					inverted = true;
					invert();
					audio.Play();
				}
			}
		}
#endif
		
		if(inverted && (!audio.isPlaying)) //revert inverted image when audio is not playing
		{
			inverted = false;
			invert();
		}
		
		return;
	}
	
	/*
		Inverts the texture's pixels
		1. Creates an empty texture
		2. Paints the texture with inverse colors of the original
		3. Swaps the texture with the original
		4. (Relies on garbage collection) 
	*/
	void invert()
	{
		if(!inverted)
		{
			//replace the texture image with the original image
			guiTexture.texture = image;
		}
		else
		{
			//replace the texture image with the inverse copy
			guiTexture.texture = inverse;
		}
		
		return;
	}
}
