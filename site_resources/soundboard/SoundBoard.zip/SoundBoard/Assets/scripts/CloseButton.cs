/*
	Sound Board
	by Maverick Loneshark
	5/22/2012
*/

using UnityEngine;
using System.Collections;

public class CloseButton : MonoBehaviour
{
	// Use this for initialization
	void Start()
	{
		return;
	}
	
	// Update is called once per frame
	void Update()
	{
#if UNITY_ANDROID
		//get input for Android devices
		foreach(Touch touch in Input.touches)
		{
			if(touch.phase == TouchPhase.Began)
			{
				if(guiTexture.HitTest(touch.position)) //button is pressed
				{
					Application.Quit();
				}
			}
		}
#else
		//get input for dev environment (Windows)
		if(Input.GetMouseButtonUp(0))
		{
			if(guiTexture.HitTest(Input.mousePosition)) //button is pressed
			{
				Application.Quit();
			}
		}
#endif
		
		return;
	}
}
